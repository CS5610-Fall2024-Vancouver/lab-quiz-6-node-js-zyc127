const express = require('express');
const router = express.Router();

let users = [
  { id: 1, name: 'Alice' },
  { id: 2, name: 'Bob' },
];

router.get('/', (req, res) => {
  res.json(users);
});


router.get('/:id', (req, res) => {
  const userId = parseInt(req.params.id, 10);
  const user = users.find(u => u.id === userId);

  if (user) {
    res.json(user);
  } else {
    res.status(404).send('User not found' );
  }
});


router.post('/', (req, res) => {
  const name = req.body.name;
  const newUser = {
    id: users.length + 1,
    name: name,
  };
  users.push(newUser);
  res.status(201).json(newUser);
  });

router.delete('/:id', (req, res) => {
  const userId = parseInt(req.params.id, 10);
  users = users.filter(u => u.id !== userId);
  res.status(204).send();
});

module.exports = router;
